package com.ecocoinx.app

import com.ecocoinx.app.appcomponents.base.BaseActivity
import com.ecocoinx.app.databinding.LayoutProgressDialogBinding

class MainActivity : BaseActivity<LayoutProgressDialogBinding>(R.layout.layout_progress_dialog) {

    override fun onInitialized() {

    }

    override fun setUpClicks() {

    }
}