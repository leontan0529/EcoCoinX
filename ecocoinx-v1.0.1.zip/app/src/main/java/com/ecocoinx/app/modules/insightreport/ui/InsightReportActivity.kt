package com.ecocoinx.app.modules.insightreport.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import com.ecocoinx.app.R
import com.ecocoinx.app.appcomponents.base.BaseActivity
import com.ecocoinx.app.databinding.ActivityInsightReportBinding
import com.ecocoinx.app.modules.insightreport.`data`.viewmodel.InsightReportVM
import kotlin.String
import kotlin.Unit

class InsightReportActivity :
    BaseActivity<ActivityInsightReportBinding>(R.layout.activity_insight_report) {
  private val viewModel: InsightReportVM by viewModels<InsightReportVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.insightReportVM = viewModel
  }

  override fun setUpClicks(): Unit {
  }

  companion object {
    const val TAG: String = "INSIGHT_REPORT_ACTIVITY"


    fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, InsightReportActivity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
