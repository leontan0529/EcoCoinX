package com.ecocoinx.app.modules.sellconfirmation.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.ecocoinx.app.modules.sellconfirmation.`data`.model.SellConfirmationModel
import org.koin.core.KoinComponent

class SellConfirmationVM : ViewModel(), KoinComponent {
  val sellConfirmationModel: MutableLiveData<SellConfirmationModel> =
      MutableLiveData(SellConfirmationModel())

  var navArguments: Bundle? = null
}
