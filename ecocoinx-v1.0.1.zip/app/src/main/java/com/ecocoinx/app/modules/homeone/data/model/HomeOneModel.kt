package com.ecocoinx.app.modules.homeone.`data`.model

import com.ecocoinx.app.R
import com.ecocoinx.app.appcomponents.di.MyApp
import kotlin.String

data class HomeOneModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtWelcomeMark: String? = MyApp.getInstance().resources.getString(R.string.lbl_welcome_mark)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtMakeyourfirst: String? =
      MyApp.getInstance().resources.getString(R.string.msg_make_your_first)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtTrendingCoins: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_trending_coins)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtLanguage: String? = MyApp.getInstance().resources.getString(R.string.lbl_nature_ecocoin)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtBTC: String? = MyApp.getInstance().resources.getString(R.string.lbl_nec)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtPrice: String? = MyApp.getInstance().resources.getString(R.string.lbl_25_75)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtNineHundredSeventySeven: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_9_77)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtTechEcoCoin: String? = MyApp.getInstance().resources.getString(R.string.lbl_tech_ecocoin)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtTEC: String? = MyApp.getInstance().resources.getString(R.string.lbl_tec)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtPriceOne: String? = MyApp.getInstance().resources.getString(R.string.lbl_19_75)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txt2100: String? = MyApp.getInstance().resources.getString(R.string.lbl_21_00)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtCoinsInTheNe: String? =
      MyApp.getInstance().resources.getString(R.string.msg_coins_in_the_ne)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtCountry: String? = MyApp.getInstance().resources.getString(R.string.msg_why_bitcoiners)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtElonMuskSays: String? =
      MyApp.getInstance().resources.getString(R.string.msg_elon_musk_says)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtCoindeskOne: String? = MyApp.getInstance().resources.getString(R.string.lbl_coindesk)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txt16hrsago: String? = MyApp.getInstance().resources.getString(R.string.lbl_16_hrs_ago)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtOffer: String? = MyApp.getInstance().resources.getString(R.string.msg_grayscale_disc)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtWhatisgoingo: String? =
      MyApp.getInstance().resources.getString(R.string.msg_what_is_going_o)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtPrivacyconcern: String? =
      MyApp.getInstance().resources.getString(R.string.msg_privacy_concern)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtCountryOne: String? = MyApp.getInstance().resources.getString(R.string.msg_why_bitcoiners)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDecryptOne: String? = MyApp.getInstance().resources.getString(R.string.lbl_decrypt)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txt12hrsagoOne: String? = MyApp.getInstance().resources.getString(R.string.lbl_12_hrs_ago)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txt08hrsagoOne: String? = MyApp.getInstance().resources.getString(R.string.lbl_08_hrs_ago)

)
