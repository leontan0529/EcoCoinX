package com.ecocoinx.app.modules.ecoeddieone.ui

import androidx.activity.viewModels
import com.ecocoinx.app.R
import com.ecocoinx.app.appcomponents.base.BaseActivity
import com.ecocoinx.app.databinding.ActivityEcoeddieOneBinding
import com.ecocoinx.app.modules.ecoeddieone.`data`.viewmodel.EcoeddieOneVM
import kotlin.String
import kotlin.Unit

class EcoeddieOneActivity : BaseActivity<ActivityEcoeddieOneBinding>(R.layout.activity_ecoeddie_one)
    {
  private val viewModel: EcoeddieOneVM by viewModels<EcoeddieOneVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.ecoeddieOneVM = viewModel
  }

  override fun setUpClicks(): Unit {
  }

  companion object {
    const val TAG: String = "ECOEDDIE_ONE_ACTIVITY"

  }
}
