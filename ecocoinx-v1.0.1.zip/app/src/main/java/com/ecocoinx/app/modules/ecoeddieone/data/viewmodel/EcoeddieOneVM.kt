package com.ecocoinx.app.modules.ecoeddieone.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.ecocoinx.app.modules.ecoeddieone.`data`.model.EcoeddieOneModel
import org.koin.core.KoinComponent

class EcoeddieOneVM : ViewModel(), KoinComponent {
  val ecoeddieOneModel: MutableLiveData<EcoeddieOneModel> = MutableLiveData(EcoeddieOneModel())

  var navArguments: Bundle? = null
}
