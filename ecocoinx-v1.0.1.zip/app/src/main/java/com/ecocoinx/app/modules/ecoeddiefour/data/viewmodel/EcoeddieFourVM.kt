package com.ecocoinx.app.modules.ecoeddiefour.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.ecocoinx.app.modules.ecoeddiefour.`data`.model.EcoeddieFourModel
import org.koin.core.KoinComponent

class EcoeddieFourVM : ViewModel(), KoinComponent {
  val ecoeddieFourModel: MutableLiveData<EcoeddieFourModel> = MutableLiveData(EcoeddieFourModel())

  var navArguments: Bundle? = null
}
