package com.ecocoinx.app.modules.buyconfirmation.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.ecocoinx.app.modules.buyconfirmation.`data`.model.BuyConfirmationModel
import org.koin.core.KoinComponent

class BuyConfirmationVM : ViewModel(), KoinComponent {
  val buyConfirmationModel: MutableLiveData<BuyConfirmationModel> =
      MutableLiveData(BuyConfirmationModel())

  var navArguments: Bundle? = null
}
