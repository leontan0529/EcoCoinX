package com.ecocoinx.app.modules.homeonecontainer.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import com.ecocoinx.app.R
import com.ecocoinx.app.appcomponents.base.BaseActivity
import com.ecocoinx.app.databinding.ActivityHomeOneContainerBinding
import com.ecocoinx.app.extensions.loadFragment
import com.ecocoinx.app.modules.homeone.ui.HomeOneFragment
import com.ecocoinx.app.modules.homeonecontainer.`data`.viewmodel.HomeOneContainerVM
import com.ecocoinx.app.modules.portfolio.ui.PortfolioFragment
import com.ecocoinx.app.modules.profile.ui.ProfileFragment
import kotlin.String
import kotlin.Unit

class HomeOneContainerActivity :
    BaseActivity<ActivityHomeOneContainerBinding>(R.layout.activity_home_one_container) {
  private val viewModel: HomeOneContainerVM by viewModels<HomeOneContainerVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.homeOneContainerVM = viewModel
    val destFragment = HomeOneFragment.getInstance(null)
    this.loadFragment(
    R.id.fragmentContainer,
    destFragment,
    bundle = destFragment.arguments,
    tag = HomeOneFragment.TAG,
    addToBackStack = false,
    add = false,
    enter = null,
    exit = null,
    )
  }

  override fun setUpClicks(): Unit {
    binding.linearColumnhome.setOnClickListener {
      val destFragment = HomeOneFragment.getInstance(null)
      this.loadFragment(
      R.id.fragmentContainer,
      destFragment,
      bundle = destFragment.arguments,
      tag = HomeOneFragment.TAG,
      addToBackStack = true,
      add = false,
      enter = null,
      exit = null,
      )
    }
    binding.linearColumnforward.setOnClickListener {
      val destFragment = PortfolioFragment.getInstance(null)
      this.loadFragment(
      R.id.fragmentContainer,
      destFragment,
      bundle = destFragment.arguments,
      tag = PortfolioFragment.TAG,
      addToBackStack = true,
      add = false,
      enter = null,
      exit = null,
      )
    }
    binding.linearColumnuser.setOnClickListener {
      val destFragment = ProfileFragment.getInstance(null)
      this.loadFragment(
      R.id.fragmentContainer,
      destFragment,
      bundle = destFragment.arguments,
      tag = ProfileFragment.TAG,
      addToBackStack = true,
      add = false,
      enter = null,
      exit = null,
      )
    }
  }

  companion object {
    const val TAG: String = "HOME_ONE_CONTAINER_ACTIVITY"


    fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, HomeOneContainerActivity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
