package com.ecocoinx.app.modules.applaunchloadingpagefive.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import com.ecocoinx.app.R
import com.ecocoinx.app.appcomponents.base.BaseActivity
import com.ecocoinx.app.databinding.ActivityAppLaunchLoadingPageFiveBinding
import com.ecocoinx.app.modules.applaunchloadingpagefive.`data`.viewmodel.AppLaunchLoadingPageFiveVM
import com.ecocoinx.app.modules.applaunchloadingpagesix.ui.AppLaunchLoadingPageSixActivity
import kotlin.String
import kotlin.Unit

class AppLaunchLoadingPageFiveActivity :
    BaseActivity<ActivityAppLaunchLoadingPageFiveBinding>(R.layout.activity_app_launch_loading_page_five)
    {
  private val viewModel: AppLaunchLoadingPageFiveVM by viewModels<AppLaunchLoadingPageFiveVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.appLaunchLoadingPageFiveVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.btnSignIn.setOnClickListener {
      val destIntent = AppLaunchLoadingPageSixActivity.getIntent(this, null)
      startActivity(destIntent)
    }
  }

  companion object {
    const val TAG: String = "APP_LAUNCH_LOADING_PAGE_FIVE_ACTIVITY"


    fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, AppLaunchLoadingPageFiveActivity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
