package com.ecocoinx.app.modules.coinpageone.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.activity.viewModels
import com.ecocoinx.app.R
import com.ecocoinx.app.appcomponents.base.BaseActivity
import com.ecocoinx.app.databinding.ActivityCoinPageOneBinding
import com.ecocoinx.app.modules.buyone.ui.BuyOneActivity
import com.ecocoinx.app.modules.coinpageone.`data`.model.ListcoindeskTwo1RowModel
import com.ecocoinx.app.modules.coinpageone.`data`.model.ListvideocameraRowModel
import com.ecocoinx.app.modules.coinpageone.`data`.viewmodel.CoinPageOneVM
import com.ecocoinx.app.modules.homeonecontainer.ui.HomeOneContainerActivity
import com.ecocoinx.app.modules.sellone.ui.SellOneActivity
import kotlin.Int
import kotlin.String
import kotlin.Unit

class CoinPageOneActivity :
    BaseActivity<ActivityCoinPageOneBinding>(R.layout.activity_coin_page_one) {
  private val viewModel: CoinPageOneVM by viewModels<CoinPageOneVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    val listvideocameraAdapter =
    ListvideocameraAdapter(viewModel.listvideocameraList.value?:mutableListOf())
    binding.recyclerListvideocamera.adapter = listvideocameraAdapter
    listvideocameraAdapter.setOnItemClickListener(
    object : ListvideocameraAdapter.OnItemClickListener {
      override fun onItemClick(view:View, position:Int, item : ListvideocameraRowModel) {
        onClickRecyclerListvideocamera(view, position, item)
      }
    }
    )
    viewModel.listvideocameraList.observe(this) {
      listvideocameraAdapter.updateData(it)
    }
    val listcoindeskTwoAdapter =
    ListcoindeskTwoAdapter(viewModel.listcoindeskTwoList.value?:mutableListOf())
    binding.recyclerListcoindeskTwo.adapter = listcoindeskTwoAdapter
    listcoindeskTwoAdapter.setOnItemClickListener(
    object : ListcoindeskTwoAdapter.OnItemClickListener {
      override fun onItemClick(view:View, position:Int, item : ListcoindeskTwo1RowModel) {
        onClickRecyclerListcoindeskTwo(view, position, item)
      }
    }
    )
    viewModel.listcoindeskTwoList.observe(this) {
      listcoindeskTwoAdapter.updateData(it)
    }
    binding.coinPageOneVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.btnSell.setOnClickListener {
      val destIntent = SellOneActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.btnBuy.setOnClickListener {
      val destIntent = BuyOneActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.imageArrowleft.setOnClickListener {
      val destIntent = HomeOneContainerActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.imageArrowleft.setOnClickListener {
      finish()
    }
  }

  fun onClickRecyclerListvideocamera(
    view: View,
    position: Int,
    item: ListvideocameraRowModel
  ): Unit {
    when(view.id) {
    }
  }

  fun onClickRecyclerListcoindeskTwo(
    view: View,
    position: Int,
    item: ListcoindeskTwo1RowModel
  ): Unit {
    when(view.id) {
    }
  }

  companion object {
    const val TAG: String = "COIN_PAGE_ONE_ACTIVITY"


    fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, CoinPageOneActivity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
