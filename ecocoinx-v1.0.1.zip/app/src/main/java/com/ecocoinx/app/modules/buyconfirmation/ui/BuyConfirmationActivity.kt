package com.ecocoinx.app.modules.buyconfirmation.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import com.ecocoinx.app.R
import com.ecocoinx.app.appcomponents.base.BaseActivity
import com.ecocoinx.app.databinding.ActivityBuyConfirmationBinding
import com.ecocoinx.app.modules.buyconfirmation.`data`.viewmodel.BuyConfirmationVM
import com.ecocoinx.app.modules.buyone.ui.BuyOneActivity
import com.ecocoinx.app.modules.buysellverificationone.ui.BuySellVerificationOneActivity
import kotlin.String
import kotlin.Unit

class BuyConfirmationActivity :
    BaseActivity<ActivityBuyConfirmationBinding>(R.layout.activity_buy_confirmation) {
  private val viewModel: BuyConfirmationVM by viewModels<BuyConfirmationVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.buyConfirmationVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.imageArrowleft.setOnClickListener {
      val destIntent = BuyOneActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.imageArrowleft.setOnClickListener {
      finish()
    }
    binding.btnConfirm.setOnClickListener {
      val destIntent = BuySellVerificationOneActivity.getIntent(this, null)
      startActivity(destIntent)
    }
  }

  companion object {
    const val TAG: String = "BUY_CONFIRMATION_ACTIVITY"


    fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, BuyConfirmationActivity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
