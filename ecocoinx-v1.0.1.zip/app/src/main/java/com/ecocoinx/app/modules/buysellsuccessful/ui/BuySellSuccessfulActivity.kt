package com.ecocoinx.app.modules.buysellsuccessful.ui

import androidx.activity.viewModels
import com.ecocoinx.app.R
import com.ecocoinx.app.appcomponents.base.BaseActivity
import com.ecocoinx.app.databinding.ActivityBuySellSuccessfulBinding
import com.ecocoinx.app.modules.buysellsuccessful.`data`.viewmodel.BuySellSuccessfulVM
import com.ecocoinx.app.modules.homeonecontainer.ui.HomeOneContainerActivity
import kotlin.String
import kotlin.Unit

class BuySellSuccessfulActivity :
    BaseActivity<ActivityBuySellSuccessfulBinding>(R.layout.activity_buy_sell_successful) {
  private val viewModel: BuySellSuccessfulVM by viewModels<BuySellSuccessfulVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.buySellSuccessfulVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.imageArrowleft.setOnClickListener {
      finish()
    }
    binding.txtReturntohomep.setOnClickListener {
      val destIntent = HomeOneContainerActivity.getIntent(this, null)
      startActivity(destIntent)
    }
  }

  companion object {
    const val TAG: String = "BUY_SELL_SUCCESSFUL_ACTIVITY"

  }
}
