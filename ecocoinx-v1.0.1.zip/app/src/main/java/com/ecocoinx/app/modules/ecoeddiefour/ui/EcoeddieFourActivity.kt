package com.ecocoinx.app.modules.ecoeddiefour.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import com.ecocoinx.app.R
import com.ecocoinx.app.appcomponents.base.BaseActivity
import com.ecocoinx.app.databinding.ActivityEcoeddieFourBinding
import com.ecocoinx.app.modules.ecoeddiefour.`data`.viewmodel.EcoeddieFourVM
import kotlin.String
import kotlin.Unit

class EcoeddieFourActivity :
    BaseActivity<ActivityEcoeddieFourBinding>(R.layout.activity_ecoeddie_four) {
  private val viewModel: EcoeddieFourVM by viewModels<EcoeddieFourVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.ecoeddieFourVM = viewModel
  }

  override fun setUpClicks(): Unit {
  }

  companion object {
    const val TAG: String = "ECOEDDIE_FOUR_ACTIVITY"


    fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, EcoeddieFourActivity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
