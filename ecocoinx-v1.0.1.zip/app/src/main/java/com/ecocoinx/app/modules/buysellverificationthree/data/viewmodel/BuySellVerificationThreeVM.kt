package com.ecocoinx.app.modules.buysellverificationthree.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.ecocoinx.app.modules.buysellverificationthree.`data`.model.BuySellVerificationThreeModel
import org.koin.core.KoinComponent

class BuySellVerificationThreeVM : ViewModel(), KoinComponent {
  val buySellVerificationThreeModel: MutableLiveData<BuySellVerificationThreeModel> =
      MutableLiveData(BuySellVerificationThreeModel())

  var navArguments: Bundle? = null
}
