package com.ecocoinx.app.modules.loadingpage1.ui

import androidx.activity.viewModels
import com.ecocoinx.app.R
import com.ecocoinx.app.appcomponents.base.BaseActivity
import com.ecocoinx.app.databinding.ActivityLoadingPage1Binding
import com.ecocoinx.app.modules.loadingpage1.`data`.viewmodel.LoadingPage1VM
import kotlin.String
import kotlin.Unit

class LoadingPage1Activity :
    BaseActivity<ActivityLoadingPage1Binding>(R.layout.activity_loading_page_1) {
  private val viewModel: LoadingPage1VM by viewModels<LoadingPage1VM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.loadingPage1VM = viewModel
  }

  override fun setUpClicks(): Unit {
  }

  companion object {
    const val TAG: String = "LOADING_PAGE1ACTIVITY"

  }
}
