package com.ecocoinx.app.modules.applaunchloadingpage.`data`.model

import com.ecocoinx.app.R
import com.ecocoinx.app.appcomponents.di.MyApp
import kotlin.String

data class AppLaunchLoadingPageModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtEcoCoinX: String? = MyApp.getInstance().resources.getString(R.string.lbl_ecocoinx)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtLanguage: String? = MyApp.getInstance().resources.getString(R.string.msg_1_rated_crypto)

)
