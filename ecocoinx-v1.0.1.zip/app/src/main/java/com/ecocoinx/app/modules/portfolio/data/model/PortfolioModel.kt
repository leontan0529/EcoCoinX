package com.ecocoinx.app.modules.portfolio.`data`.model

import com.ecocoinx.app.R
import com.ecocoinx.app.appcomponents.di.MyApp
import kotlin.String

data class PortfolioModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtPortfolio: String? = MyApp.getInstance().resources.getString(R.string.lbl_portfolio)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtLanguage: String? = MyApp.getInstance().resources.getString(R.string.lbl_ecocoin_balance)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtPrice: String? = MyApp.getInstance().resources.getString(R.string.lbl_1_209_75)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtNineHundredSeventySeven: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_9_77)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtSoldEcoCoin: String? = MyApp.getInstance().resources.getString(R.string.lbl_sold_ecocoin)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtPriceOne: String? = MyApp.getInstance().resources.getString(R.string.lbl_1_618_75)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtBoughtEcoCoin: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_bought_ecocoin)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtPriceTwo: String? = MyApp.getInstance().resources.getString(R.string.lbl_589)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtYourcoins: String? = MyApp.getInstance().resources.getString(R.string.lbl_your_coins)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtTechEcoCoin: String? = MyApp.getInstance().resources.getString(R.string.lbl_tech_ecocoin)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtTEC: String? = MyApp.getInstance().resources.getString(R.string.lbl_tec)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtPriceThree: String? = MyApp.getInstance().resources.getString(R.string.lbl_19_75)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txt2100: String? = MyApp.getInstance().resources.getString(R.string.lbl_21_00)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtINSIGHTSFORYO: String? =
      MyApp.getInstance().resources.getString(R.string.msg_insights_for_yo)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtBETA: String? = MyApp.getInstance().resources.getString(R.string.lbl_beta)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDescription: String? =
      MyApp.getInstance().resources.getString(R.string.msg_activity_analys)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtViewFullRepor: String? =
      MyApp.getInstance().resources.getString(R.string.msg_view_full_repor)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtLanguageOne: String? =
      MyApp.getInstance().resources.getString(R.string.msg_generated_by_ec)

)
