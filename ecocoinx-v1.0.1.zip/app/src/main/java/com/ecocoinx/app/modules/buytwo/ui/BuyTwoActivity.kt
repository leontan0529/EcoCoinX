package com.ecocoinx.app.modules.buytwo.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.activity.viewModels
import com.ecocoinx.app.R
import com.ecocoinx.app.appcomponents.base.BaseActivity
import com.ecocoinx.app.databinding.ActivityBuyTwoBinding
import com.ecocoinx.app.modules.buyconfirmation.ui.BuyConfirmationActivity
import com.ecocoinx.app.modules.buytwo.`data`.model.BuyTwoRowModel
import com.ecocoinx.app.modules.buytwo.`data`.viewmodel.BuyTwoVM
import com.ecocoinx.app.modules.coinpageone.ui.CoinPageOneActivity
import com.ecocoinx.app.modules.sellone.ui.SellOneActivity
import kotlin.Int
import kotlin.String
import kotlin.Unit

class BuyTwoActivity : BaseActivity<ActivityBuyTwoBinding>(R.layout.activity_buy_two) {
  private val viewModel: BuyTwoVM by viewModels<BuyTwoVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    val buytwoAdapter = BuytwoAdapter(viewModel.buytwoList.value?:mutableListOf())
    binding.recyclerBuytwo.adapter = buytwoAdapter
    buytwoAdapter.setOnItemClickListener(
    object : BuytwoAdapter.OnItemClickListener {
      override fun onItemClick(view:View, position:Int, item : BuyTwoRowModel) {
        onClickRecyclerBuytwo(view, position, item)
      }
    }
    )
    viewModel.buytwoList.observe(this) {
      buytwoAdapter.updateData(it)
    }
    binding.buyTwoVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.imageArrowleft.setOnClickListener {
      val destIntent = CoinPageOneActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.imageArrowleft.setOnClickListener {
      finish()
    }
    binding.btnSellNec.setOnClickListener {
      val destIntent = SellOneActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.btnPreviewBuy.setOnClickListener {
      val destIntent = BuyConfirmationActivity.getIntent(this, null)
      startActivity(destIntent)
    }
  }

  fun onClickRecyclerBuytwo(
    view: View,
    position: Int,
    item: BuyTwoRowModel
  ): Unit {
    when(view.id) {
    }
  }

  companion object {
    const val TAG: String = "BUY_TWO_ACTIVITY"


    fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, BuyTwoActivity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
