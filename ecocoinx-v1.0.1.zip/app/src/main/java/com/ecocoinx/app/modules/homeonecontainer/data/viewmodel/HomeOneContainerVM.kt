package com.ecocoinx.app.modules.homeonecontainer.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.ecocoinx.app.modules.homeonecontainer.`data`.model.HomeOneContainerModel
import org.koin.core.KoinComponent

class HomeOneContainerVM : ViewModel(), KoinComponent {
  val homeOneContainerModel: MutableLiveData<HomeOneContainerModel> =
      MutableLiveData(HomeOneContainerModel())

  var navArguments: Bundle? = null
}
