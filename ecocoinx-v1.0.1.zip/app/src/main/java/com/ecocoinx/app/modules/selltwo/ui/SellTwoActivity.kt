package com.ecocoinx.app.modules.selltwo.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.activity.viewModels
import com.ecocoinx.app.R
import com.ecocoinx.app.appcomponents.base.BaseActivity
import com.ecocoinx.app.databinding.ActivitySellTwoBinding
import com.ecocoinx.app.modules.buyone.ui.BuyOneActivity
import com.ecocoinx.app.modules.coinpageone.ui.CoinPageOneActivity
import com.ecocoinx.app.modules.sellconfirmation.ui.SellConfirmationActivity
import com.ecocoinx.app.modules.selltwo.`data`.model.SellTwoRowModel
import com.ecocoinx.app.modules.selltwo.`data`.viewmodel.SellTwoVM
import kotlin.Int
import kotlin.String
import kotlin.Unit

class SellTwoActivity : BaseActivity<ActivitySellTwoBinding>(R.layout.activity_sell_two) {
  private val viewModel: SellTwoVM by viewModels<SellTwoVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    val selltwoAdapter = SelltwoAdapter(viewModel.selltwoList.value?:mutableListOf())
    binding.recyclerSelltwo.adapter = selltwoAdapter
    selltwoAdapter.setOnItemClickListener(
    object : SelltwoAdapter.OnItemClickListener {
      override fun onItemClick(view:View, position:Int, item : SellTwoRowModel) {
        onClickRecyclerSelltwo(view, position, item)
      }
    }
    )
    viewModel.selltwoList.observe(this) {
      selltwoAdapter.updateData(it)
    }
    binding.sellTwoVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.imageArrowleft.setOnClickListener {
      val destIntent = CoinPageOneActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.imageArrowleft.setOnClickListener {
      finish()
    }
    binding.btnBuyNec.setOnClickListener {
      val destIntent = BuyOneActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.btnPreviewSell.setOnClickListener {
      val destIntent = SellConfirmationActivity.getIntent(this, null)
      startActivity(destIntent)
    }
  }

  fun onClickRecyclerSelltwo(
    view: View,
    position: Int,
    item: SellTwoRowModel
  ): Unit {
    when(view.id) {
    }
  }

  companion object {
    const val TAG: String = "SELL_TWO_ACTIVITY"


    fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, SellTwoActivity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
