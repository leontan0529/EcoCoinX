package com.ecocoinx.app.modules.applaunchloadingpagefive.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.ecocoinx.app.modules.applaunchloadingpagefive.`data`.model.AppLaunchLoadingPageFiveModel
import org.koin.core.KoinComponent

class AppLaunchLoadingPageFiveVM : ViewModel(), KoinComponent {
  val appLaunchLoadingPageFiveModel: MutableLiveData<AppLaunchLoadingPageFiveModel> =
      MutableLiveData(AppLaunchLoadingPageFiveModel())

  var navArguments: Bundle? = null
}
