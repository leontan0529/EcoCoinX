package com.ecocoinx.app.modules.buysellverificationone.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.ecocoinx.app.modules.buysellverificationone.`data`.model.BuySellVerificationOneModel
import org.koin.core.KoinComponent

class BuySellVerificationOneVM : ViewModel(), KoinComponent {
  val buySellVerificationOneModel: MutableLiveData<BuySellVerificationOneModel> =
      MutableLiveData(BuySellVerificationOneModel())

  var navArguments: Bundle? = null
}
