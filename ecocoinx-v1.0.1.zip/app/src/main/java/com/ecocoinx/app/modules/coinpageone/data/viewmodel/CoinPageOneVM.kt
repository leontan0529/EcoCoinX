package com.ecocoinx.app.modules.coinpageone.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.ecocoinx.app.modules.coinpageone.`data`.model.CoinPageOneModel
import com.ecocoinx.app.modules.coinpageone.`data`.model.ListcoindeskTwo1RowModel
import com.ecocoinx.app.modules.coinpageone.`data`.model.ListvideocameraRowModel
import kotlin.collections.MutableList
import org.koin.core.KoinComponent

class CoinPageOneVM : ViewModel(), KoinComponent {
  val coinPageOneModel: MutableLiveData<CoinPageOneModel> = MutableLiveData(CoinPageOneModel())

  var navArguments: Bundle? = null

  val listvideocameraList: MutableLiveData<MutableList<ListvideocameraRowModel>> =
      MutableLiveData(mutableListOf())

  val listcoindeskTwoList: MutableLiveData<MutableList<ListcoindeskTwo1RowModel>> =
      MutableLiveData(mutableListOf())
}
