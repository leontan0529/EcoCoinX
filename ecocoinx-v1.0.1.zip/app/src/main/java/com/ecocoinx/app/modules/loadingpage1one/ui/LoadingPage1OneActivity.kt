package com.ecocoinx.app.modules.loadingpage1one.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import com.ecocoinx.app.R
import com.ecocoinx.app.appcomponents.base.BaseActivity
import com.ecocoinx.app.databinding.ActivityLoadingPage1OneBinding
import com.ecocoinx.app.modules.loadingpage1one.`data`.viewmodel.LoadingPage1OneVM
import kotlin.String
import kotlin.Unit

class LoadingPage1OneActivity :
    BaseActivity<ActivityLoadingPage1OneBinding>(R.layout.activity_loading_page_1_one) {
  private val viewModel: LoadingPage1OneVM by viewModels<LoadingPage1OneVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.loadingPage1OneVM = viewModel
  }

  override fun setUpClicks(): Unit {
  }

  companion object {
    const val TAG: String = "LOADING_PAGE1ONE_ACTIVITY"


    fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, LoadingPage1OneActivity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
