package com.ecocoinx.app.modules.applaunchloadingpagefour.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import com.ecocoinx.app.R
import com.ecocoinx.app.appcomponents.base.BaseActivity
import com.ecocoinx.app.databinding.ActivityAppLaunchLoadingPageFourBinding
import com.ecocoinx.app.modules.applaunchloadingpagefour.`data`.viewmodel.AppLaunchLoadingPageFourVM
import com.ecocoinx.app.modules.loadingpage1one.ui.LoadingPage1OneActivity
import kotlin.String
import kotlin.Unit

class AppLaunchLoadingPageFourActivity :
    BaseActivity<ActivityAppLaunchLoadingPageFourBinding>(R.layout.activity_app_launch_loading_page_four)
    {
  private val viewModel: AppLaunchLoadingPageFourVM by viewModels<AppLaunchLoadingPageFourVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.appLaunchLoadingPageFourVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.btnSignIn.setOnClickListener {
      val destIntent = LoadingPage1OneActivity.getIntent(this, null)
      startActivity(destIntent)
    }
  }

  companion object {
    const val TAG: String = "APP_LAUNCH_LOADING_PAGE_FOUR_ACTIVITY"


    fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, AppLaunchLoadingPageFourActivity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
