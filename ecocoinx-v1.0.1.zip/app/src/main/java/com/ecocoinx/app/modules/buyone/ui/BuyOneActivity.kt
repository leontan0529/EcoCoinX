package com.ecocoinx.app.modules.buyone.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.activity.viewModels
import com.ecocoinx.app.R
import com.ecocoinx.app.appcomponents.base.BaseActivity
import com.ecocoinx.app.databinding.ActivityBuyOneBinding
import com.ecocoinx.app.modules.buyone.`data`.model.BuyOneRowModel
import com.ecocoinx.app.modules.buyone.`data`.viewmodel.BuyOneVM
import com.ecocoinx.app.modules.buytwo.ui.BuyTwoActivity
import com.ecocoinx.app.modules.coinpageone.ui.CoinPageOneActivity
import com.ecocoinx.app.modules.sellone.ui.SellOneActivity
import kotlin.Int
import kotlin.String
import kotlin.Unit

class BuyOneActivity : BaseActivity<ActivityBuyOneBinding>(R.layout.activity_buy_one) {
  private val viewModel: BuyOneVM by viewModels<BuyOneVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    val buyoneAdapter = BuyoneAdapter(viewModel.buyoneList.value?:mutableListOf())
    binding.recyclerBuyone.adapter = buyoneAdapter
    buyoneAdapter.setOnItemClickListener(
    object : BuyoneAdapter.OnItemClickListener {
      override fun onItemClick(view:View, position:Int, item : BuyOneRowModel) {
        onClickRecyclerBuyone(view, position, item)
      }
    }
    )
    viewModel.buyoneList.observe(this) {
      buyoneAdapter.updateData(it)
    }
    binding.buyOneVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.imageArrowleft.setOnClickListener {
      val destIntent = CoinPageOneActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.imageArrowleft.setOnClickListener {
      finish()
    }
    binding.btnSellNec.setOnClickListener {
      val destIntent = SellOneActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.btnPreviewBuy.setOnClickListener {
      val destIntent = BuyTwoActivity.getIntent(this, null)
      startActivity(destIntent)
    }
  }

  fun onClickRecyclerBuyone(
    view: View,
    position: Int,
    item: BuyOneRowModel
  ): Unit {
    when(view.id) {
    }
  }

  companion object {
    const val TAG: String = "BUY_ONE_ACTIVITY"


    fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, BuyOneActivity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
