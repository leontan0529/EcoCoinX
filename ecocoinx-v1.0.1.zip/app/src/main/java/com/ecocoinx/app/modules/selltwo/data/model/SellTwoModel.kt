package com.ecocoinx.app.modules.selltwo.`data`.model

import com.ecocoinx.app.R
import com.ecocoinx.app.appcomponents.di.MyApp
import kotlin.String

data class SellTwoModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtSellNatureEco: String? =
      MyApp.getInstance().resources.getString(R.string.msg_sell_nature_eco)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtNEC: String? = MyApp.getInstance().resources.getString(R.string.lbl_nec2)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtECXAmount: String? = MyApp.getInstance().resources.getString(R.string.lbl_ecx_amount)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtThreeHundredEightyThree: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_3_83)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtECX: String? = MyApp.getInstance().resources.getString(R.string.lbl_ecx)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtMin00001ECX: String? = MyApp.getInstance().resources.getString(R.string.msg_min_0_0001_ecx)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtLanguage: String? = MyApp.getInstance().resources.getString(R.string.msg_available_balan)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtFrameSeven: String? = MyApp.getInstance().resources.getString(R.string.lbl_02)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtFrameEight: String? = MyApp.getInstance().resources.getString(R.string.lbl_10)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtFrameNine: String? = MyApp.getInstance().resources.getString(R.string.lbl_25)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtFrameTwelve: String? = MyApp.getInstance().resources.getString(R.string.lbl_50)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtFrameTen: String? = MyApp.getInstance().resources.getString(R.string.lbl_75)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtFrameEleven: String? = MyApp.getInstance().resources.getString(R.string.lbl_100)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtThirteen: String? = MyApp.getInstance().resources.getString(R.string.lbl5)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtZero: String? = MyApp.getInstance().resources.getString(R.string.lbl_03)

)
