package com.ecocoinx.app.modules.buysellverificationone.`data`.model

import com.ecocoinx.app.R
import com.ecocoinx.app.appcomponents.di.MyApp
import kotlin.String

data class BuySellVerificationOneModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtConfirmPurchas: String? =
      MyApp.getInstance().resources.getString(R.string.msg_confirm_purchas)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtVerifying: String? = MyApp.getInstance().resources.getString(R.string.lbl_verifying)

)
