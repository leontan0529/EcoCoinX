package com.ecocoinx.app.modules.insightreportone.`data`.model

import com.ecocoinx.app.R
import com.ecocoinx.app.appcomponents.di.MyApp
import kotlin.String

data class InsightReportOneModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtDescription: String? = MyApp.getInstance().resources.getString(R.string.msg_dear_mark_gre)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtThatisequival: String? =
      MyApp.getInstance().resources.getString(R.string.msg_that_is_equival)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtOne: String? = MyApp.getInstance().resources.getString(R.string.lbl3)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtViewResources: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_view_resources)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtViewSentiment: String? =
      MyApp.getInstance().resources.getString(R.string.msg_view_sentiment)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtGiveFeedback: String? = MyApp.getInstance().resources.getString(R.string.lbl_give_feedback)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtHomeOne: String? = MyApp.getInstance().resources.getString(R.string.lbl_home)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtPortfolio: String? = MyApp.getInstance().resources.getString(R.string.lbl_portfolio)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtEcoEddie: String? = MyApp.getInstance().resources.getString(R.string.lbl_ecoeddie)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtMarket: String? = MyApp.getInstance().resources.getString(R.string.lbl_market)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtProfile: String? = MyApp.getInstance().resources.getString(R.string.lbl_profile)

)
