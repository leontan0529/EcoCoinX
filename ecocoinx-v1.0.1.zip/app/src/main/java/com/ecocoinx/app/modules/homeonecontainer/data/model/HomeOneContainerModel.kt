package com.ecocoinx.app.modules.homeonecontainer.`data`.model

import com.ecocoinx.app.R
import com.ecocoinx.app.appcomponents.di.MyApp
import kotlin.String

data class HomeOneContainerModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtHomeOne: String? = MyApp.getInstance().resources.getString(R.string.lbl_home)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtPortfolio: String? = MyApp.getInstance().resources.getString(R.string.lbl_portfolio)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtEcoEddie: String? = MyApp.getInstance().resources.getString(R.string.lbl_ecoeddie)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtMarket: String? = MyApp.getInstance().resources.getString(R.string.lbl_market)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtProfile: String? = MyApp.getInstance().resources.getString(R.string.lbl_profile)

)
