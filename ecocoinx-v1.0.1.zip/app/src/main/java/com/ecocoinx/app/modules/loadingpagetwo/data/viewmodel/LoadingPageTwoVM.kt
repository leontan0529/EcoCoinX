package com.ecocoinx.app.modules.loadingpagetwo.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.ecocoinx.app.modules.loadingpagetwo.`data`.model.LoadingPageTwoModel
import org.koin.core.KoinComponent

class LoadingPageTwoVM : ViewModel(), KoinComponent {
  val loadingPageTwoModel: MutableLiveData<LoadingPageTwoModel> =
      MutableLiveData(LoadingPageTwoModel())

  var navArguments: Bundle? = null
}
