package com.ecocoinx.app.modules.applaunchloadingpage.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.ecocoinx.app.modules.applaunchloadingpage.`data`.model.AppLaunchLoadingPageModel
import org.koin.core.KoinComponent

class AppLaunchLoadingPageVM : ViewModel(), KoinComponent {
  val appLaunchLoadingPageModel: MutableLiveData<AppLaunchLoadingPageModel> =
      MutableLiveData(AppLaunchLoadingPageModel())

  var navArguments: Bundle? = null
}
