package com.ecocoinx.app.modules.buyconfirmation.`data`.model

import com.ecocoinx.app.R
import com.ecocoinx.app.appcomponents.di.MyApp
import kotlin.String

data class BuyConfirmationModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtConfirmPurchas: String? =
      MyApp.getInstance().resources.getString(R.string.msg_confirm_purchas)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtPleasereviewy: String? =
      MyApp.getInstance().resources.getString(R.string.msg_please_review_y)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txt383ECX: String? = MyApp.getInstance().resources.getString(R.string.lbl_3_83_ecx)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtPrice: String? = MyApp.getInstance().resources.getString(R.string.lbl_1003)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtNatureEcoCoin: String? =
      MyApp.getInstance().resources.getString(R.string.msg_nature_ecocoin)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtPriceOne: String? = MyApp.getInstance().resources.getString(R.string.msg_current_balance)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtLanguage: String? = MyApp.getInstance().resources.getString(R.string.msg_available_balan)

)
