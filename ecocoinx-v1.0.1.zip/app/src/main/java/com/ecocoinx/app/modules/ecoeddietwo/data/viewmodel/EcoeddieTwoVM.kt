package com.ecocoinx.app.modules.ecoeddietwo.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.ecocoinx.app.modules.ecoeddietwo.`data`.model.EcoeddieTwoModel
import org.koin.core.KoinComponent

class EcoeddieTwoVM : ViewModel(), KoinComponent {
  val ecoeddieTwoModel: MutableLiveData<EcoeddieTwoModel> = MutableLiveData(EcoeddieTwoModel())

  var navArguments: Bundle? = null
}
