package com.ecocoinx.app.modules.ecoeddiethree.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import com.ecocoinx.app.R
import com.ecocoinx.app.appcomponents.base.BaseActivity
import com.ecocoinx.app.databinding.ActivityEcoeddieThreeBinding
import com.ecocoinx.app.modules.ecoeddiefour.ui.EcoeddieFourActivity
import com.ecocoinx.app.modules.ecoeddiethree.`data`.viewmodel.EcoeddieThreeVM
import kotlin.String
import kotlin.Unit

class EcoeddieThreeActivity :
    BaseActivity<ActivityEcoeddieThreeBinding>(R.layout.activity_ecoeddie_three) {
  private val viewModel: EcoeddieThreeVM by viewModels<EcoeddieThreeVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.ecoeddieThreeVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.imageImageFour.setOnClickListener {
      val destIntent = EcoeddieFourActivity.getIntent(this, null)
      startActivity(destIntent)
    }
  }

  companion object {
    const val TAG: String = "ECOEDDIE_THREE_ACTIVITY"


    fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, EcoeddieThreeActivity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
