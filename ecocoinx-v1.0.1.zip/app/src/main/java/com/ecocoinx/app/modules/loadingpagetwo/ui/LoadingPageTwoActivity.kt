package com.ecocoinx.app.modules.loadingpagetwo.ui

import androidx.activity.viewModels
import com.ecocoinx.app.R
import com.ecocoinx.app.appcomponents.base.BaseActivity
import com.ecocoinx.app.databinding.ActivityLoadingPageTwoBinding
import com.ecocoinx.app.modules.loadingpagetwo.`data`.viewmodel.LoadingPageTwoVM
import kotlin.String
import kotlin.Unit

class LoadingPageTwoActivity :
    BaseActivity<ActivityLoadingPageTwoBinding>(R.layout.activity_loading_page_two) {
  private val viewModel: LoadingPageTwoVM by viewModels<LoadingPageTwoVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.loadingPageTwoVM = viewModel
  }

  override fun setUpClicks(): Unit {
  }

  companion object {
    const val TAG: String = "LOADING_PAGE_TWO_ACTIVITY"

  }
}
