package com.ecocoinx.app.modules.ecoeddietwo.ui

import androidx.activity.viewModels
import com.ecocoinx.app.R
import com.ecocoinx.app.appcomponents.base.BaseActivity
import com.ecocoinx.app.databinding.ActivityEcoeddieTwoBinding
import com.ecocoinx.app.modules.ecoeddiethree.ui.EcoeddieThreeActivity
import com.ecocoinx.app.modules.ecoeddietwo.`data`.viewmodel.EcoeddieTwoVM
import kotlin.String
import kotlin.Unit

class EcoeddieTwoActivity : BaseActivity<ActivityEcoeddieTwoBinding>(R.layout.activity_ecoeddie_two)
    {
  private val viewModel: EcoeddieTwoVM by viewModels<EcoeddieTwoVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.ecoeddieTwoVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.linearRowtypeyourconce.setOnClickListener {
      val destIntent = EcoeddieThreeActivity.getIntent(this, null)
      startActivity(destIntent)
    }
  }

  companion object {
    const val TAG: String = "ECOEDDIE_TWO_ACTIVITY"

  }
}
