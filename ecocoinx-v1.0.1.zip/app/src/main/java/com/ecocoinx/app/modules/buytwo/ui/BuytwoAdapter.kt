package com.ecocoinx.app.modules.buytwo.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.ecocoinx.app.R
import com.ecocoinx.app.databinding.RowBuyTwoBinding
import com.ecocoinx.app.modules.buytwo.`data`.model.BuyTwoRowModel
import kotlin.Int
import kotlin.collections.List

class BuytwoAdapter(
  var list: List<BuyTwoRowModel>
) : RecyclerView.Adapter<BuytwoAdapter.RowBuyTwoVH>() {
  private var clickListener: OnItemClickListener? = null

  override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RowBuyTwoVH {
    val view=LayoutInflater.from(parent.context).inflate(R.layout.row_buy_two,parent,false)
    return RowBuyTwoVH(view)
  }

  override fun onBindViewHolder(holder: RowBuyTwoVH, position: Int) {
    val buyTwoRowModel = BuyTwoRowModel()
    // TODO uncomment following line after integration with data source
    // val buyTwoRowModel = list[position]
    holder.binding.buyTwoRowModel = buyTwoRowModel
  }

  override fun getItemCount(): Int = 3
  // TODO uncomment following line after integration with data source
  // return list.size

  public fun updateData(newData: List<BuyTwoRowModel>) {
    list = newData
    notifyDataSetChanged()
  }

  fun setOnItemClickListener(clickListener: OnItemClickListener) {
    this.clickListener = clickListener
  }

  interface OnItemClickListener {
    fun onItemClick(
      view: View,
      position: Int,
      item: BuyTwoRowModel
    ) {
    }
  }

  inner class RowBuyTwoVH(
    view: View
  ) : RecyclerView.ViewHolder(view) {
    val binding: RowBuyTwoBinding = RowBuyTwoBinding.bind(itemView)
  }
}
