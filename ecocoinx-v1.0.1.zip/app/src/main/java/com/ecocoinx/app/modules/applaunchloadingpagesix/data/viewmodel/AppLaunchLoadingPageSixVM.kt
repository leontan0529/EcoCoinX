package com.ecocoinx.app.modules.applaunchloadingpagesix.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.ecocoinx.app.modules.applaunchloadingpagesix.`data`.model.AppLaunchLoadingPageSixModel
import org.koin.core.KoinComponent

class AppLaunchLoadingPageSixVM : ViewModel(), KoinComponent {
  val appLaunchLoadingPageSixModel: MutableLiveData<AppLaunchLoadingPageSixModel> =
      MutableLiveData(AppLaunchLoadingPageSixModel())

  var navArguments: Bundle? = null
}
