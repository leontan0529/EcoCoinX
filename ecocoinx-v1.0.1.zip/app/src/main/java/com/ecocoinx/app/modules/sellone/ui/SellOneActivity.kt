package com.ecocoinx.app.modules.sellone.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.activity.viewModels
import com.ecocoinx.app.R
import com.ecocoinx.app.appcomponents.base.BaseActivity
import com.ecocoinx.app.databinding.ActivitySellOneBinding
import com.ecocoinx.app.modules.buyone.ui.BuyOneActivity
import com.ecocoinx.app.modules.coinpageone.ui.CoinPageOneActivity
import com.ecocoinx.app.modules.sellone.`data`.model.SellOneRowModel
import com.ecocoinx.app.modules.sellone.`data`.viewmodel.SellOneVM
import com.ecocoinx.app.modules.selltwo.ui.SellTwoActivity
import kotlin.Int
import kotlin.String
import kotlin.Unit

class SellOneActivity : BaseActivity<ActivitySellOneBinding>(R.layout.activity_sell_one) {
  private val viewModel: SellOneVM by viewModels<SellOneVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    val selloneAdapter = SelloneAdapter(viewModel.selloneList.value?:mutableListOf())
    binding.recyclerSellone.adapter = selloneAdapter
    selloneAdapter.setOnItemClickListener(
    object : SelloneAdapter.OnItemClickListener {
      override fun onItemClick(view:View, position:Int, item : SellOneRowModel) {
        onClickRecyclerSellone(view, position, item)
      }
    }
    )
    viewModel.selloneList.observe(this) {
      selloneAdapter.updateData(it)
    }
    binding.sellOneVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.imageArrowleft.setOnClickListener {
      val destIntent = CoinPageOneActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.imageArrowleft.setOnClickListener {
      finish()
    }
    binding.btnPreviewSell.setOnClickListener {
      val destIntent = SellTwoActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.btnBuyNec.setOnClickListener {
      val destIntent = BuyOneActivity.getIntent(this, null)
      startActivity(destIntent)
    }
  }

  fun onClickRecyclerSellone(
    view: View,
    position: Int,
    item: SellOneRowModel
  ): Unit {
    when(view.id) {
    }
  }

  companion object {
    const val TAG: String = "SELL_ONE_ACTIVITY"


    fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, SellOneActivity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
