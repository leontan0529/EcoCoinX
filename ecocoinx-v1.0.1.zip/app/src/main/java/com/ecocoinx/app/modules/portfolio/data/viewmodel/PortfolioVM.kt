package com.ecocoinx.app.modules.portfolio.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.ecocoinx.app.modules.portfolio.`data`.model.PortfolioModel
import org.koin.core.KoinComponent

class PortfolioVM : ViewModel(), KoinComponent {
  val portfolioModel: MutableLiveData<PortfolioModel> = MutableLiveData(PortfolioModel())

  var navArguments: Bundle? = null
}
