package com.ecocoinx.app.modules.buysellsuccessful.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.ecocoinx.app.modules.buysellsuccessful.`data`.model.BuySellSuccessfulModel
import org.koin.core.KoinComponent

class BuySellSuccessfulVM : ViewModel(), KoinComponent {
  val buySellSuccessfulModel: MutableLiveData<BuySellSuccessfulModel> =
      MutableLiveData(BuySellSuccessfulModel())

  var navArguments: Bundle? = null
}
