package com.ecocoinx.app.modules.insightreportone.ui

import androidx.activity.viewModels
import com.ecocoinx.app.R
import com.ecocoinx.app.appcomponents.base.BaseActivity
import com.ecocoinx.app.databinding.ActivityInsightReportOneBinding
import com.ecocoinx.app.modules.insightreport.ui.InsightReportActivity
import com.ecocoinx.app.modules.insightreportone.`data`.viewmodel.InsightReportOneVM
import kotlin.String
import kotlin.Unit

class InsightReportOneActivity :
    BaseActivity<ActivityInsightReportOneBinding>(R.layout.activity_insight_report_one) {
  private val viewModel: InsightReportOneVM by viewModels<InsightReportOneVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.insightReportOneVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.viewRectangleFortyTwo.setOnClickListener {
      val destIntent = InsightReportActivity.getIntent(this, null)
      startActivity(destIntent)
    }
  }

  companion object {
    const val TAG: String = "INSIGHT_REPORT_ONE_ACTIVITY"

  }
}
