package com.ecocoinx.app.modules.portfolio.ui

import android.os.Bundle
import androidx.fragment.app.viewModels
import com.ecocoinx.app.R
import com.ecocoinx.app.appcomponents.base.BaseFragment
import com.ecocoinx.app.databinding.FragmentPortfolioBinding
import com.ecocoinx.app.modules.coinpageone.ui.CoinPageOneActivity
import com.ecocoinx.app.modules.portfolio.`data`.viewmodel.PortfolioVM
import kotlin.String
import kotlin.Unit

class PortfolioFragment : BaseFragment<FragmentPortfolioBinding>(R.layout.fragment_portfolio) {
  private val viewModel: PortfolioVM by viewModels<PortfolioVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = arguments
    binding.portfolioVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.btnSellEcocoin.setOnClickListener {
      val destIntent = CoinPageOneActivity.getIntent(requireActivity(), null)
      startActivity(destIntent)
      requireActivity().onBackPressed()
    }
    binding.btnBuyEcocoin.setOnClickListener {
      val destIntent = CoinPageOneActivity.getIntent(requireActivity(), null)
      startActivity(destIntent)
      requireActivity().onBackPressed()
    }
  }

  companion object {
    const val TAG: String = "PORTFOLIO_FRAGMENT"


    fun getInstance(bundle: Bundle?): PortfolioFragment {
      val fragment = PortfolioFragment()
      fragment.arguments = bundle
      return fragment
    }
  }
}
