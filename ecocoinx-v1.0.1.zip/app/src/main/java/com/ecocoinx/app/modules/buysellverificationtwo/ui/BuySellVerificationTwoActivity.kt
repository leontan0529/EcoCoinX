package com.ecocoinx.app.modules.buysellverificationtwo.ui

import androidx.activity.viewModels
import com.ecocoinx.app.R
import com.ecocoinx.app.appcomponents.base.BaseActivity
import com.ecocoinx.app.databinding.ActivityBuySellVerificationTwoBinding
import com.ecocoinx.app.modules.buysellverificationtwo.`data`.viewmodel.BuySellVerificationTwoVM
import kotlin.String
import kotlin.Unit

class BuySellVerificationTwoActivity :
    BaseActivity<ActivityBuySellVerificationTwoBinding>(R.layout.activity_buy_sell_verification_two)
    {
  private val viewModel: BuySellVerificationTwoVM by viewModels<BuySellVerificationTwoVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.buySellVerificationTwoVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.imageArrowleft.setOnClickListener {
      finish()
    }
  }

  companion object {
    const val TAG: String = "BUY_SELL_VERIFICATION_TWO_ACTIVITY"

  }
}
