package com.ecocoinx.app.modules.applaunchloadingpagetwo.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import com.ecocoinx.app.R
import com.ecocoinx.app.appcomponents.base.BaseActivity
import com.ecocoinx.app.databinding.ActivityAppLaunchLoadingPageTwoBinding
import com.ecocoinx.app.modules.applaunchloadingpagefive.ui.AppLaunchLoadingPageFiveActivity
import com.ecocoinx.app.modules.applaunchloadingpagethree.ui.AppLaunchLoadingPageThreeActivity
import com.ecocoinx.app.modules.applaunchloadingpagetwo.`data`.viewmodel.AppLaunchLoadingPageTwoVM
import kotlin.String
import kotlin.Unit

class AppLaunchLoadingPageTwoActivity :
    BaseActivity<ActivityAppLaunchLoadingPageTwoBinding>(R.layout.activity_app_launch_loading_page_two)
    {
  private val viewModel: AppLaunchLoadingPageTwoVM by viewModels<AppLaunchLoadingPageTwoVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.appLaunchLoadingPageTwoVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.btnSignIn.setOnClickListener {
      val destIntent = AppLaunchLoadingPageFiveActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.etGroupSix.setOnClickListener {
      val destIntent = AppLaunchLoadingPageThreeActivity.getIntent(this, null)
      startActivity(destIntent)
    }
  }

  companion object {
    const val TAG: String = "APP_LAUNCH_LOADING_PAGE_TWO_ACTIVITY"


    fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, AppLaunchLoadingPageTwoActivity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
