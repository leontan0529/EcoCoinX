package com.ecocoinx.app.modules.buysellverificationone.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import com.ecocoinx.app.R
import com.ecocoinx.app.appcomponents.base.BaseActivity
import com.ecocoinx.app.databinding.ActivityBuySellVerificationOneBinding
import com.ecocoinx.app.modules.buysellverificationone.`data`.viewmodel.BuySellVerificationOneVM
import kotlin.String
import kotlin.Unit

class BuySellVerificationOneActivity :
    BaseActivity<ActivityBuySellVerificationOneBinding>(R.layout.activity_buy_sell_verification_one)
    {
  private val viewModel: BuySellVerificationOneVM by viewModels<BuySellVerificationOneVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.buySellVerificationOneVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.imageArrowleft.setOnClickListener {
      finish()
    }
  }

  companion object {
    const val TAG: String = "BUY_SELL_VERIFICATION_ONE_ACTIVITY"


    fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, BuySellVerificationOneActivity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
