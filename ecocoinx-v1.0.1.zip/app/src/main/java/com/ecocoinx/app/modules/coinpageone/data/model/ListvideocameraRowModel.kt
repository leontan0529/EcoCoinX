package com.ecocoinx.app.modules.coinpageone.`data`.model

import com.ecocoinx.app.R
import com.ecocoinx.app.appcomponents.di.MyApp
import kotlin.String

data class ListvideocameraRowModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtMarketCap: String? = MyApp.getInstance().resources.getString(R.string.lbl_market_cap)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtPriceFour: String? = MyApp.getInstance().resources.getString(R.string.lbl_2_3_billion)

)
