package com.ecocoinx.app.modules.loadingpagethree.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.ecocoinx.app.modules.loadingpagethree.`data`.model.LoadingPageThreeModel
import org.koin.core.KoinComponent

class LoadingPageThreeVM : ViewModel(), KoinComponent {
  val loadingPageThreeModel: MutableLiveData<LoadingPageThreeModel> =
      MutableLiveData(LoadingPageThreeModel())

  var navArguments: Bundle? = null
}
