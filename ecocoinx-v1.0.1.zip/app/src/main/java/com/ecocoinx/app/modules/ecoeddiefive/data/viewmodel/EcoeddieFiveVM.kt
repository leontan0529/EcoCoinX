package com.ecocoinx.app.modules.ecoeddiefive.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.ecocoinx.app.modules.ecoeddiefive.`data`.model.EcoeddieFiveModel
import org.koin.core.KoinComponent

class EcoeddieFiveVM : ViewModel(), KoinComponent {
  val ecoeddieFiveModel: MutableLiveData<EcoeddieFiveModel> = MutableLiveData(EcoeddieFiveModel())

  var navArguments: Bundle? = null
}
