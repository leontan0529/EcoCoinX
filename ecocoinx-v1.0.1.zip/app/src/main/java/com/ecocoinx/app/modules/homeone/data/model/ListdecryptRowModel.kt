package com.ecocoinx.app.modules.homeone.`data`.model

import com.ecocoinx.app.R
import com.ecocoinx.app.appcomponents.di.MyApp
import kotlin.String

data class ListdecryptRowModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtDecrypt: String? = MyApp.getInstance().resources.getString(R.string.lbl_decrypt)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txt12hrsago: String? = MyApp.getInstance().resources.getString(R.string.lbl_12_hrs_ago)

)
