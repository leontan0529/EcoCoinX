package com.ecocoinx.app.modules.buytwo.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.ecocoinx.app.modules.buytwo.`data`.model.BuyTwoModel
import com.ecocoinx.app.modules.buytwo.`data`.model.BuyTwoRowModel
import kotlin.collections.MutableList
import org.koin.core.KoinComponent

class BuyTwoVM : ViewModel(), KoinComponent {
  val buyTwoModel: MutableLiveData<BuyTwoModel> = MutableLiveData(BuyTwoModel())

  var navArguments: Bundle? = null

  val buytwoList: MutableLiveData<MutableList<BuyTwoRowModel>> = MutableLiveData(mutableListOf())
}
