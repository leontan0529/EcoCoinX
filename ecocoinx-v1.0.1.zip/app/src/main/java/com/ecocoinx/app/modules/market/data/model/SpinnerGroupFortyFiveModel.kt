package com.ecocoinx.app.modules.market.`data`.model

import kotlin.String

data class SpinnerGroupFortyFiveModel(
  val itemName: String
)
