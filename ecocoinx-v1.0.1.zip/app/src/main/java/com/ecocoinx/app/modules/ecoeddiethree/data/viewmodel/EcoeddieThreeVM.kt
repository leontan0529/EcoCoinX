package com.ecocoinx.app.modules.ecoeddiethree.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.ecocoinx.app.modules.ecoeddiethree.`data`.model.EcoeddieThreeModel
import org.koin.core.KoinComponent

class EcoeddieThreeVM : ViewModel(), KoinComponent {
  val ecoeddieThreeModel: MutableLiveData<EcoeddieThreeModel> =
      MutableLiveData(EcoeddieThreeModel())

  var navArguments: Bundle? = null
}
