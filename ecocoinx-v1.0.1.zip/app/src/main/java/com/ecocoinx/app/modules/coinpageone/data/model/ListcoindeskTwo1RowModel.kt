package com.ecocoinx.app.modules.coinpageone.`data`.model

import com.ecocoinx.app.R
import com.ecocoinx.app.appcomponents.di.MyApp
import kotlin.String

data class ListcoindeskTwo1RowModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtCoindeskTwo: String? = MyApp.getInstance().resources.getString(R.string.lbl_coindesk)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txt16hrsagoOne: String? = MyApp.getInstance().resources.getString(R.string.lbl_16_hrs_ago)

)
