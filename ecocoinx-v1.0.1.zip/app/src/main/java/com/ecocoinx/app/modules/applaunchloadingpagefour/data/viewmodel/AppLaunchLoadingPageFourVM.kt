package com.ecocoinx.app.modules.applaunchloadingpagefour.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.ecocoinx.app.modules.applaunchloadingpagefour.`data`.model.AppLaunchLoadingPageFourModel
import org.koin.core.KoinComponent

class AppLaunchLoadingPageFourVM : ViewModel(), KoinComponent {
  val appLaunchLoadingPageFourModel: MutableLiveData<AppLaunchLoadingPageFourModel> =
      MutableLiveData(AppLaunchLoadingPageFourModel())

  var navArguments: Bundle? = null
}
