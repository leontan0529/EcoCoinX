package com.ecocoinx.app.modules.insightreport.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.ecocoinx.app.modules.insightreport.`data`.model.InsightReportModel
import org.koin.core.KoinComponent

class InsightReportVM : ViewModel(), KoinComponent {
  val insightReportModel: MutableLiveData<InsightReportModel> =
      MutableLiveData(InsightReportModel())

  var navArguments: Bundle? = null
}
