package com.ecocoinx.app.modules.applaunchloadingpage.ui

import android.os.Handler
import android.os.Looper
import androidx.activity.viewModels
import com.ecocoinx.app.R
import com.ecocoinx.app.appcomponents.base.BaseActivity
import com.ecocoinx.app.databinding.ActivityAppLaunchLoadingPageBinding
import com.ecocoinx.app.modules.applaunchloadingpage.`data`.viewmodel.AppLaunchLoadingPageVM
import com.ecocoinx.app.modules.applaunchloadingpagetwo.ui.AppLaunchLoadingPageTwoActivity
import kotlin.String
import kotlin.Unit

class AppLaunchLoadingPageActivity :
    BaseActivity<ActivityAppLaunchLoadingPageBinding>(R.layout.activity_app_launch_loading_page) {
  private val viewModel: AppLaunchLoadingPageVM by viewModels<AppLaunchLoadingPageVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.appLaunchLoadingPageVM = viewModel
    Handler(Looper.getMainLooper()).postDelayed( {
      val destIntent = AppLaunchLoadingPageTwoActivity.getIntent(this, null)
      startActivity(destIntent)
      finish()
      }, 3000)
    }

    override fun setUpClicks(): Unit {
    }

    companion object {
      const val TAG: String = "APP_LAUNCH_LOADING_PAGE_ACTIVITY"

    }
  }
