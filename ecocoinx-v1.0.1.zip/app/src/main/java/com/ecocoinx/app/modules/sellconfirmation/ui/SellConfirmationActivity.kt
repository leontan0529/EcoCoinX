package com.ecocoinx.app.modules.sellconfirmation.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import com.ecocoinx.app.R
import com.ecocoinx.app.appcomponents.base.BaseActivity
import com.ecocoinx.app.databinding.ActivitySellConfirmationBinding
import com.ecocoinx.app.modules.buysellverificationone.ui.BuySellVerificationOneActivity
import com.ecocoinx.app.modules.sellconfirmation.`data`.viewmodel.SellConfirmationVM
import com.ecocoinx.app.modules.sellone.ui.SellOneActivity
import kotlin.String
import kotlin.Unit

class SellConfirmationActivity :
    BaseActivity<ActivitySellConfirmationBinding>(R.layout.activity_sell_confirmation) {
  private val viewModel: SellConfirmationVM by viewModels<SellConfirmationVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.sellConfirmationVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.linearColumnconfirm.setOnClickListener {
      val destIntent = BuySellVerificationOneActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.imageArrowleft.setOnClickListener {
      val destIntent = SellOneActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.imageArrowleft.setOnClickListener {
      finish()
    }
  }

  companion object {
    const val TAG: String = "SELL_CONFIRMATION_ACTIVITY"


    fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, SellConfirmationActivity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
