package com.ecocoinx.app.modules.buysellverificationthree.ui

import androidx.activity.viewModels
import com.ecocoinx.app.R
import com.ecocoinx.app.appcomponents.base.BaseActivity
import com.ecocoinx.app.databinding.ActivityBuySellVerificationThreeBinding
import com.ecocoinx.app.modules.buysellverificationthree.`data`.viewmodel.BuySellVerificationThreeVM
import kotlin.String
import kotlin.Unit

class BuySellVerificationThreeActivity :
    BaseActivity<ActivityBuySellVerificationThreeBinding>(R.layout.activity_buy_sell_verification_three)
    {
  private val viewModel: BuySellVerificationThreeVM by viewModels<BuySellVerificationThreeVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.buySellVerificationThreeVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.imageArrowleft.setOnClickListener {
      finish()
    }
  }

  companion object {
    const val TAG: String = "BUY_SELL_VERIFICATION_THREE_ACTIVITY"

  }
}
