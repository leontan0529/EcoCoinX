package com.ecocoinx.app.modules.selltwo.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.ecocoinx.app.modules.selltwo.`data`.model.SellTwoModel
import com.ecocoinx.app.modules.selltwo.`data`.model.SellTwoRowModel
import kotlin.collections.MutableList
import org.koin.core.KoinComponent

class SellTwoVM : ViewModel(), KoinComponent {
  val sellTwoModel: MutableLiveData<SellTwoModel> = MutableLiveData(SellTwoModel())

  var navArguments: Bundle? = null

  val selltwoList: MutableLiveData<MutableList<SellTwoRowModel>> = MutableLiveData(mutableListOf())
}
