package com.ecocoinx.app.modules.applaunchloadingpagethree.`data`.model

import com.ecocoinx.app.R
import com.ecocoinx.app.appcomponents.di.MyApp
import kotlin.String

data class AppLaunchLoadingPageThreeModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtEcoCoinX: String? = MyApp.getInstance().resources.getString(R.string.lbl_ecocoinx)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtUsername: String? = MyApp.getInstance().resources.getString(R.string.lbl_username)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtPassword: String? = MyApp.getInstance().resources.getString(R.string.lbl_password)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtForgotpassword: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_forgot_password)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtLanguage: String? = MyApp.getInstance().resources.getString(R.string.msg_1_rated_crypto)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var etGroupTwentySixValue: String? = null,
  /**
   * TODO Replace with dynamic value
   */
  var etGroupTwentyFiveValue: String? = null
)
