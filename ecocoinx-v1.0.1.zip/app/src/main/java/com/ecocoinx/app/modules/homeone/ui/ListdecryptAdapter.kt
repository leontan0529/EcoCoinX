package com.ecocoinx.app.modules.homeone.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.ecocoinx.app.R
import com.ecocoinx.app.databinding.RowListdecryptBinding
import com.ecocoinx.app.modules.homeone.`data`.model.ListdecryptRowModel
import kotlin.Int
import kotlin.collections.List

class ListdecryptAdapter(
  var list: List<ListdecryptRowModel>
) : RecyclerView.Adapter<ListdecryptAdapter.RowListdecryptVH>() {
  private var clickListener: OnItemClickListener? = null

  override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RowListdecryptVH {
    val view=LayoutInflater.from(parent.context).inflate(R.layout.row_listdecrypt,parent,false)
    return RowListdecryptVH(view)
  }

  override fun onBindViewHolder(holder: RowListdecryptVH, position: Int) {
    val listdecryptRowModel = ListdecryptRowModel()
    // TODO uncomment following line after integration with data source
    // val listdecryptRowModel = list[position]
    holder.binding.listdecryptRowModel = listdecryptRowModel
  }

  override fun getItemCount(): Int = 2
  // TODO uncomment following line after integration with data source
  // return list.size

  public fun updateData(newData: List<ListdecryptRowModel>) {
    list = newData
    notifyDataSetChanged()
  }

  fun setOnItemClickListener(clickListener: OnItemClickListener) {
    this.clickListener = clickListener
  }

  interface OnItemClickListener {
    fun onItemClick(
      view: View,
      position: Int,
      item: ListdecryptRowModel
    ) {
    }
  }

  inner class RowListdecryptVH(
    view: View
  ) : RecyclerView.ViewHolder(view) {
    val binding: RowListdecryptBinding = RowListdecryptBinding.bind(itemView)
  }
}
