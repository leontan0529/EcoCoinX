package com.ecocoinx.app.modules.loadingpage1one.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.ecocoinx.app.modules.loadingpage1one.`data`.model.LoadingPage1OneModel
import org.koin.core.KoinComponent

class LoadingPage1OneVM : ViewModel(), KoinComponent {
  val loadingPage1OneModel: MutableLiveData<LoadingPage1OneModel> =
      MutableLiveData(LoadingPage1OneModel())

  var navArguments: Bundle? = null
}
