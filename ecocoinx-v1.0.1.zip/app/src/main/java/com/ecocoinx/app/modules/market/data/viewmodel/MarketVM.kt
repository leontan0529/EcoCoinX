package com.ecocoinx.app.modules.market.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.ecocoinx.app.modules.market.`data`.model.MarketModel
import com.ecocoinx.app.modules.market.`data`.model.SpinnerGroupFortyFiveModel
import kotlin.collections.MutableList
import org.koin.core.KoinComponent

class MarketVM : ViewModel(), KoinComponent {
  val marketModel: MutableLiveData<MarketModel> = MutableLiveData(MarketModel())

  var navArguments: Bundle? = null

  val spinnerGroupFortyFiveList: MutableLiveData<MutableList<SpinnerGroupFortyFiveModel>> =
      MutableLiveData()
}
