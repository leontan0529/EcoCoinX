package com.ecocoinx.app.modules.buysellverificationfour.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.ecocoinx.app.modules.buysellverificationfour.`data`.model.BuySellVerificationFourModel
import org.koin.core.KoinComponent

class BuySellVerificationFourVM : ViewModel(), KoinComponent {
  val buySellVerificationFourModel: MutableLiveData<BuySellVerificationFourModel> =
      MutableLiveData(BuySellVerificationFourModel())

  var navArguments: Bundle? = null
}
