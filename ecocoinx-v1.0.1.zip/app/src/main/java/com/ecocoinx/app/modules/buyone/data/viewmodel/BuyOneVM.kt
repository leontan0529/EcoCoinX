package com.ecocoinx.app.modules.buyone.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.ecocoinx.app.modules.buyone.`data`.model.BuyOneModel
import com.ecocoinx.app.modules.buyone.`data`.model.BuyOneRowModel
import kotlin.collections.MutableList
import org.koin.core.KoinComponent

class BuyOneVM : ViewModel(), KoinComponent {
  val buyOneModel: MutableLiveData<BuyOneModel> = MutableLiveData(BuyOneModel())

  var navArguments: Bundle? = null

  val buyoneList: MutableLiveData<MutableList<BuyOneRowModel>> = MutableLiveData(mutableListOf())
}
