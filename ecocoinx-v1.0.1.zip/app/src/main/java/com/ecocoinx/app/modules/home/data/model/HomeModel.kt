package com.ecocoinx.app.modules.home.`data`.model

import com.ecocoinx.app.R
import com.ecocoinx.app.appcomponents.di.MyApp
import kotlin.String

data class HomeModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtCoinsInTheNe: String? =
      MyApp.getInstance().resources.getString(R.string.msg_coins_in_the_ne)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtWorldEF: String? = MyApp.getInstance().resources.getString(R.string.lbl_world_e_f)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDuration: String? = MyApp.getInstance().resources.getString(R.string.lbl_1_day_ago)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtPrivacyconcern: String? =
      MyApp.getInstance().resources.getString(R.string.msg_privacy_concern)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDescription: String? = MyApp.getInstance().resources.getString(R.string.msg_as_governments)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtHomeOne: String? = MyApp.getInstance().resources.getString(R.string.lbl_home)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtPortfolio: String? = MyApp.getInstance().resources.getString(R.string.lbl_portfolio)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtEcoEddie: String? = MyApp.getInstance().resources.getString(R.string.lbl_ecoeddie)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtMarket: String? = MyApp.getInstance().resources.getString(R.string.lbl_market)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtProfile: String? = MyApp.getInstance().resources.getString(R.string.lbl_profile)

)
