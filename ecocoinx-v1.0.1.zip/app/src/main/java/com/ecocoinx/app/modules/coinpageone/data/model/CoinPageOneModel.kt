package com.ecocoinx.app.modules.coinpageone.`data`.model

import com.ecocoinx.app.R
import com.ecocoinx.app.appcomponents.di.MyApp
import kotlin.String

data class CoinPageOneModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtNatureEcoCoin: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_nature_ecocoin2)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtNEC: String? = MyApp.getInstance().resources.getString(R.string.lbl_nec2)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtPrice: String? = MyApp.getInstance().resources.getString(R.string.lbl_25_75)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txt2515977: String? = MyApp.getInstance().resources.getString(R.string.lbl_2_515_9_77)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtPriceOne: String? = MyApp.getInstance().resources.getString(R.string.lbl_25_75)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtPriceTwo: String? = MyApp.getInstance().resources.getString(R.string.lbl_11_18)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtTime: String? = MyApp.getInstance().resources.getString(R.string.lbl_04_16)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtTimeOne: String? = MyApp.getInstance().resources.getString(R.string.lbl_06_54)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtTimeTwo: String? = MyApp.getInstance().resources.getString(R.string.lbl_09_18)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtTimeThree: String? = MyApp.getInstance().resources.getString(R.string.lbl_14_57)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtTimeFour: String? = MyApp.getInstance().resources.getString(R.string.lbl_16_29)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtHCounter: String? = MyApp.getInstance().resources.getString(R.string.lbl_1_h)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtHCounterOne: String? = MyApp.getInstance().resources.getString(R.string.lbl_24_h)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtWCounter: String? = MyApp.getInstance().resources.getString(R.string.lbl_1_w)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDistance: String? = MyApp.getInstance().resources.getString(R.string.lbl_1_m)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDistanceOne: String? = MyApp.getInstance().resources.getString(R.string.lbl_6_m)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtLanguage: String? = MyApp.getInstance().resources.getString(R.string.lbl_1_y)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtFrameEleven: String? = MyApp.getInstance().resources.getString(R.string.lbl_all)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtNatureEcoCoinOne: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_nature_ecocoin2)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtNecCounter: String? = MyApp.getInstance().resources.getString(R.string.lbl_00_00_nec)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtPriceThree: String? = MyApp.getInstance().resources.getString(R.string.lbl_00_00)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txt0000: String? = MyApp.getInstance().resources.getString(R.string.lbl_00_002)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtTransactions: String? = MyApp.getInstance().resources.getString(R.string.lbl_transactions)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtMarketStats: String? = MyApp.getInstance().resources.getString(R.string.lbl_market_stats)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAbout: String? = MyApp.getInstance().resources.getString(R.string.lbl_about)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDescription: String? =
      MyApp.getInstance().resources.getString(R.string.msg_ecocoinx_s_firs)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtCoinsInTheNe: String? =
      MyApp.getInstance().resources.getString(R.string.msg_coins_in_the_ne)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtCountry: String? = MyApp.getInstance().resources.getString(R.string.msg_why_bitcoiners)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDecrypt: String? = MyApp.getInstance().resources.getString(R.string.lbl_decrypt)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txt12hrsago: String? = MyApp.getInstance().resources.getString(R.string.lbl_12_hrs_ago)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtOffer: String? = MyApp.getInstance().resources.getString(R.string.msg_grayscale_disc)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtCoindesk: String? = MyApp.getInstance().resources.getString(R.string.lbl_coindesk)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txt08hrsago: String? = MyApp.getInstance().resources.getString(R.string.lbl_08_hrs_ago)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtElonMuskSays: String? =
      MyApp.getInstance().resources.getString(R.string.msg_elon_musk_says)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtCoindeskOne: String? = MyApp.getInstance().resources.getString(R.string.lbl_coindesk)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txt16hrsago: String? = MyApp.getInstance().resources.getString(R.string.lbl_16_hrs_ago)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtWhatisgoingo: String? =
      MyApp.getInstance().resources.getString(R.string.msg_what_is_going_o)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtPrivacyconcern: String? =
      MyApp.getInstance().resources.getString(R.string.msg_privacy_concern)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtCountryOne: String? = MyApp.getInstance().resources.getString(R.string.msg_why_bitcoiners)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDecryptOne: String? = MyApp.getInstance().resources.getString(R.string.lbl_decrypt)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txt12hrsagoOne: String? = MyApp.getInstance().resources.getString(R.string.lbl_12_hrs_ago)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txt08hrsagoOne: String? = MyApp.getInstance().resources.getString(R.string.lbl_08_hrs_ago)

)
