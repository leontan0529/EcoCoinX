package com.ecocoinx.app.modules.applaunchloadingpagetwo.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.ecocoinx.app.modules.applaunchloadingpagetwo.`data`.model.AppLaunchLoadingPageTwoModel
import org.koin.core.KoinComponent

class AppLaunchLoadingPageTwoVM : ViewModel(), KoinComponent {
  val appLaunchLoadingPageTwoModel: MutableLiveData<AppLaunchLoadingPageTwoModel> =
      MutableLiveData(AppLaunchLoadingPageTwoModel())

  var navArguments: Bundle? = null
}
