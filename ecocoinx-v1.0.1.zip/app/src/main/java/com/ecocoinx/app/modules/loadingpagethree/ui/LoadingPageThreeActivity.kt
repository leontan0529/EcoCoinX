package com.ecocoinx.app.modules.loadingpagethree.ui

import androidx.activity.viewModels
import com.ecocoinx.app.R
import com.ecocoinx.app.appcomponents.base.BaseActivity
import com.ecocoinx.app.databinding.ActivityLoadingPageThreeBinding
import com.ecocoinx.app.modules.loadingpagethree.`data`.viewmodel.LoadingPageThreeVM
import kotlin.String
import kotlin.Unit

class LoadingPageThreeActivity :
    BaseActivity<ActivityLoadingPageThreeBinding>(R.layout.activity_loading_page_three) {
  private val viewModel: LoadingPageThreeVM by viewModels<LoadingPageThreeVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.loadingPageThreeVM = viewModel
  }

  override fun setUpClicks(): Unit {
  }

  companion object {
    const val TAG: String = "LOADING_PAGE_THREE_ACTIVITY"

  }
}
