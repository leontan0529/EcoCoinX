package com.ecocoinx.app.modules.buysellsuccessful.`data`.model

import com.ecocoinx.app.R
import com.ecocoinx.app.appcomponents.di.MyApp
import kotlin.String

data class BuySellSuccessfulModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtConfirmPurchas: String? =
      MyApp.getInstance().resources.getString(R.string.msg_confirm_purchas)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtSuccess: String? = MyApp.getInstance().resources.getString(R.string.lbl_success)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtReturntohomep: String? =
      MyApp.getInstance().resources.getString(R.string.msg_return_to_homep)

)
