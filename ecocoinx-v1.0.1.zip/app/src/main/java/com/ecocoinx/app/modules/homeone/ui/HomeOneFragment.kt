package com.ecocoinx.app.modules.homeone.ui

import android.os.Bundle
import android.view.View
import androidx.fragment.app.viewModels
import com.ecocoinx.app.R
import com.ecocoinx.app.appcomponents.base.BaseFragment
import com.ecocoinx.app.databinding.FragmentHomeOneBinding
import com.ecocoinx.app.modules.homeone.`data`.model.ListcoindeskTwoRowModel
import com.ecocoinx.app.modules.homeone.`data`.model.ListdecryptRowModel
import com.ecocoinx.app.modules.homeone.`data`.viewmodel.HomeOneVM
import kotlin.Int
import kotlin.String
import kotlin.Unit

class HomeOneFragment : BaseFragment<FragmentHomeOneBinding>(R.layout.fragment_home_one) {
  private val viewModel: HomeOneVM by viewModels<HomeOneVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = arguments
    val listdecryptAdapter =
    ListdecryptAdapter(viewModel.listdecryptList.value?:mutableListOf())
    binding.recyclerListdecrypt.adapter = listdecryptAdapter
    listdecryptAdapter.setOnItemClickListener(
    object : ListdecryptAdapter.OnItemClickListener {
      override fun onItemClick(view:View, position:Int, item : ListdecryptRowModel) {
        onClickRecyclerListdecrypt(view, position, item)
      }
    }
    )
    viewModel.listdecryptList.observe(requireActivity()) {
      listdecryptAdapter.updateData(it)
    }
    val listcoindeskTwoAdapter =
    ListcoindeskTwoAdapter(viewModel.listcoindeskTwoList.value?:mutableListOf())
    binding.recyclerListcoindeskTwo.adapter = listcoindeskTwoAdapter
    listcoindeskTwoAdapter.setOnItemClickListener(
    object : ListcoindeskTwoAdapter.OnItemClickListener {
      override fun onItemClick(view:View, position:Int, item : ListcoindeskTwoRowModel) {
        onClickRecyclerListcoindeskTwo(view, position, item)
      }
    }
    )
    viewModel.listcoindeskTwoList.observe(requireActivity()) {
      listcoindeskTwoAdapter.updateData(it)
    }
    binding.homeOneVM = viewModel
  }

  override fun setUpClicks(): Unit {
  }

  fun onClickRecyclerListdecrypt(
    view: View,
    position: Int,
    item: ListdecryptRowModel
  ): Unit {
    when(view.id) {
    }
  }

  fun onClickRecyclerListcoindeskTwo(
    view: View,
    position: Int,
    item: ListcoindeskTwoRowModel
  ): Unit {
    when(view.id) {
    }
  }

  companion object {
    const val TAG: String = "HOME_ONE_FRAGMENT"


    fun getInstance(bundle: Bundle?): HomeOneFragment {
      val fragment = HomeOneFragment()
      fragment.arguments = bundle
      return fragment
    }
  }
}
