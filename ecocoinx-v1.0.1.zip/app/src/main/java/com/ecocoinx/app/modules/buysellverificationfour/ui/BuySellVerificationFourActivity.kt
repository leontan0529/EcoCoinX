package com.ecocoinx.app.modules.buysellverificationfour.ui

import androidx.activity.viewModels
import com.ecocoinx.app.R
import com.ecocoinx.app.appcomponents.base.BaseActivity
import com.ecocoinx.app.databinding.ActivityBuySellVerificationFourBinding
import com.ecocoinx.app.modules.buysellverificationfour.`data`.viewmodel.BuySellVerificationFourVM
import kotlin.String
import kotlin.Unit

class BuySellVerificationFourActivity :
    BaseActivity<ActivityBuySellVerificationFourBinding>(R.layout.activity_buy_sell_verification_four)
    {
  private val viewModel: BuySellVerificationFourVM by viewModels<BuySellVerificationFourVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.buySellVerificationFourVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.imageArrowleft.setOnClickListener {
      finish()
    }
  }

  companion object {
    const val TAG: String = "BUY_SELL_VERIFICATION_FOUR_ACTIVITY"

  }
}
