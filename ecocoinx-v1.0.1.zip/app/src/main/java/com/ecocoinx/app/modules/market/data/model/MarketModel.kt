package com.ecocoinx.app.modules.market.`data`.model

import com.ecocoinx.app.R
import com.ecocoinx.app.appcomponents.di.MyApp
import kotlin.String

data class MarketModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtDuration: String? = MyApp.getInstance().resources.getString(R.string.msg_in_the_past_24)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtMarketisdown: String? =
      MyApp.getInstance().resources.getString(R.string.msg_market_is_down)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtMarketisdownOne: String? =
      MyApp.getInstance().resources.getString(R.string.msg_market_is_down)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDurationOne: String? = MyApp.getInstance().resources.getString(R.string.msg_in_the_past_24)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtCoins: String? = MyApp.getInstance().resources.getString(R.string.lbl_coins)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtCoinsOne: String? = MyApp.getInstance().resources.getString(R.string.lbl_coins)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAll: String? = MyApp.getInstance().resources.getString(R.string.lbl_all)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtGainer: String? = MyApp.getInstance().resources.getString(R.string.lbl_gainer)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtLoser: String? = MyApp.getInstance().resources.getString(R.string.lbl_loser)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtFavourites: String? = MyApp.getInstance().resources.getString(R.string.lbl_favourites)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAllOne: String? = MyApp.getInstance().resources.getString(R.string.lbl_all)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtGainerOne: String? = MyApp.getInstance().resources.getString(R.string.lbl_gainer)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtLoserOne: String? = MyApp.getInstance().resources.getString(R.string.lbl_loser)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtFavouritesOne: String? = MyApp.getInstance().resources.getString(R.string.lbl_favourites)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtLanguage: String? = MyApp.getInstance().resources.getString(R.string.lbl_nature_ecocoin)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtBTC: String? = MyApp.getInstance().resources.getString(R.string.lbl_nec)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtPrice: String? = MyApp.getInstance().resources.getString(R.string.lbl_25_75)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtNineHundredSeventySeven: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_9_77)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtTechEcoCoin: String? = MyApp.getInstance().resources.getString(R.string.lbl_tech_ecocoin)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtTEC: String? = MyApp.getInstance().resources.getString(R.string.lbl_tec)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtPriceOne: String? = MyApp.getInstance().resources.getString(R.string.lbl_19_75)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txt2100: String? = MyApp.getInstance().resources.getString(R.string.lbl_21_00)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtLanguageOne: String? = MyApp.getInstance().resources.getString(R.string.lbl_nature_ecocoin)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtBTCOne: String? = MyApp.getInstance().resources.getString(R.string.lbl_nec)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtPriceTwo: String? = MyApp.getInstance().resources.getString(R.string.lbl_25_75)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtNineHundredSeventySevenOne: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_9_77)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtTechEcoCoinOne: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_tech_ecocoin)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtTECOne: String? = MyApp.getInstance().resources.getString(R.string.lbl_tec)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtPriceThree: String? = MyApp.getInstance().resources.getString(R.string.lbl_19_75)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txt2100One: String? = MyApp.getInstance().resources.getString(R.string.lbl_21_00)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtHomeOne: String? = MyApp.getInstance().resources.getString(R.string.lbl_home)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtPortfolio: String? = MyApp.getInstance().resources.getString(R.string.lbl_portfolio)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtRewards: String? = MyApp.getInstance().resources.getString(R.string.lbl_cryptogpt)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtMarket: String? = MyApp.getInstance().resources.getString(R.string.lbl_market)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtProfile: String? = MyApp.getInstance().resources.getString(R.string.lbl_profile)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtHomeThree: String? = MyApp.getInstance().resources.getString(R.string.lbl_home)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtPortfolioOne: String? = MyApp.getInstance().resources.getString(R.string.lbl_portfolio)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtRewardsOne: String? = MyApp.getInstance().resources.getString(R.string.lbl_cryptogpt)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtMarketOne: String? = MyApp.getInstance().resources.getString(R.string.lbl_market)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtProfileOne: String? = MyApp.getInstance().resources.getString(R.string.lbl_profile)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtTopStories: String? = MyApp.getInstance().resources.getString(R.string.lbl_top_stories)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtCountry: String? = MyApp.getInstance().resources.getString(R.string.msg_why_bitcoiners)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDecrypt: String? = MyApp.getInstance().resources.getString(R.string.lbl_decrypt)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txt12hrsago: String? = MyApp.getInstance().resources.getString(R.string.lbl_12_hrs_ago)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtOffer: String? = MyApp.getInstance().resources.getString(R.string.msg_grayscale_disc)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtCoindesk: String? = MyApp.getInstance().resources.getString(R.string.lbl_coindesk)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txt08hrsago: String? = MyApp.getInstance().resources.getString(R.string.lbl_08_hrs_ago)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtElonMuskSays: String? =
      MyApp.getInstance().resources.getString(R.string.msg_elon_musk_says)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtCoindeskOne: String? = MyApp.getInstance().resources.getString(R.string.lbl_coindesk)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txt16hrsago: String? = MyApp.getInstance().resources.getString(R.string.lbl_16_hrs_ago)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtHomeFive: String? = MyApp.getInstance().resources.getString(R.string.lbl_home)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtPortfolioTwo: String? = MyApp.getInstance().resources.getString(R.string.lbl_portfolio)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtRewardsTwo: String? = MyApp.getInstance().resources.getString(R.string.lbl_cryptogpt)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtMarketTwo: String? = MyApp.getInstance().resources.getString(R.string.lbl_market)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtProfileTwo: String? = MyApp.getInstance().resources.getString(R.string.lbl_profile)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtHomeSeven: String? = MyApp.getInstance().resources.getString(R.string.lbl_home)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtPortfolioThree: String? = MyApp.getInstance().resources.getString(R.string.lbl_portfolio)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtEcoEddie: String? = MyApp.getInstance().resources.getString(R.string.lbl_ecoeddie)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtMarketThree: String? = MyApp.getInstance().resources.getString(R.string.lbl_market)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtProfileThree: String? = MyApp.getInstance().resources.getString(R.string.lbl_profile)

)
