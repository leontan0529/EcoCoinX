package com.ecocoinx.app.modules.buysellverificationtwo.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.ecocoinx.app.modules.buysellverificationtwo.`data`.model.BuySellVerificationTwoModel
import org.koin.core.KoinComponent

class BuySellVerificationTwoVM : ViewModel(), KoinComponent {
  val buySellVerificationTwoModel: MutableLiveData<BuySellVerificationTwoModel> =
      MutableLiveData(BuySellVerificationTwoModel())

  var navArguments: Bundle? = null
}
