package com.ecocoinx.app.modules.market.ui

import androidx.activity.viewModels
import com.ecocoinx.app.R
import com.ecocoinx.app.appcomponents.base.BaseActivity
import com.ecocoinx.app.databinding.ActivityMarketBinding
import com.ecocoinx.app.modules.coinpageone.ui.CoinPageOneActivity
import com.ecocoinx.app.modules.market.`data`.model.SpinnerGroupFortyFiveModel
import com.ecocoinx.app.modules.market.`data`.viewmodel.MarketVM
import kotlin.String
import kotlin.Unit

class MarketActivity : BaseActivity<ActivityMarketBinding>(R.layout.activity_market) {
  private val viewModel: MarketVM by viewModels<MarketVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    viewModel.spinnerGroupFortyFiveList.value = mutableListOf(
    SpinnerGroupFortyFiveModel("Item1"),
    SpinnerGroupFortyFiveModel("Item2"),
    SpinnerGroupFortyFiveModel("Item3"),
    SpinnerGroupFortyFiveModel("Item4"),
    SpinnerGroupFortyFiveModel("Item5")
    )
    val spinnerGroupFortyFiveAdapter =
    SpinnerGroupFortyFiveAdapter(this,R.layout.spinner_item,viewModel.spinnerGroupFortyFiveList.value?:
    mutableListOf())
    binding.spinnerGroupFortyFive.adapter = spinnerGroupFortyFiveAdapter
    binding.marketVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.linearRowlanguage.setOnClickListener {
      val destIntent = CoinPageOneActivity.getIntent(this, null)
      startActivity(destIntent)
    }
  }

  companion object {
    const val TAG: String = "MARKET_ACTIVITY"

  }
}
