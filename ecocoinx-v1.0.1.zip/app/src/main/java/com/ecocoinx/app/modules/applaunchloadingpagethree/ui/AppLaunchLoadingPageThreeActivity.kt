package com.ecocoinx.app.modules.applaunchloadingpagethree.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import com.ecocoinx.app.R
import com.ecocoinx.app.appcomponents.base.BaseActivity
import com.ecocoinx.app.databinding.ActivityAppLaunchLoadingPageThreeBinding
import com.ecocoinx.app.modules.applaunchloadingpagefour.ui.AppLaunchLoadingPageFourActivity
import com.ecocoinx.app.modules.applaunchloadingpagethree.`data`.viewmodel.AppLaunchLoadingPageThreeVM
import kotlin.String
import kotlin.Unit

class AppLaunchLoadingPageThreeActivity :
    BaseActivity<ActivityAppLaunchLoadingPageThreeBinding>(R.layout.activity_app_launch_loading_page_three)
    {
  private val viewModel: AppLaunchLoadingPageThreeVM by viewModels<AppLaunchLoadingPageThreeVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.appLaunchLoadingPageThreeVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.btnSignIn.setOnClickListener {
      val destIntent = AppLaunchLoadingPageFourActivity.getIntent(this, null)
      startActivity(destIntent)
    }
  }

  companion object {
    const val TAG: String = "APP_LAUNCH_LOADING_PAGE_THREE_ACTIVITY"


    fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, AppLaunchLoadingPageThreeActivity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
