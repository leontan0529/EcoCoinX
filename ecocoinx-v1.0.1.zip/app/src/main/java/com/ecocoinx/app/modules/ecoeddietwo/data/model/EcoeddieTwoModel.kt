package com.ecocoinx.app.modules.ecoeddietwo.`data`.model

import com.ecocoinx.app.R
import com.ecocoinx.app.appcomponents.di.MyApp
import kotlin.String

data class EcoeddieTwoModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtEcoEddie: String? = MyApp.getInstance().resources.getString(R.string.lbl_ecoeddie)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtGooddayHowm: String? = MyApp.getInstance().resources.getString(R.string.msg_good_day_how_m)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtTypeyourconce: String? =
      MyApp.getInstance().resources.getString(R.string.msg_type_your_conce)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtHomeOne: String? = MyApp.getInstance().resources.getString(R.string.lbl_home)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtPortfolio: String? = MyApp.getInstance().resources.getString(R.string.lbl_portfolio)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtEcoEddieOne: String? = MyApp.getInstance().resources.getString(R.string.lbl_ecoeddie)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtMarket: String? = MyApp.getInstance().resources.getString(R.string.lbl_market)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtProfile: String? = MyApp.getInstance().resources.getString(R.string.lbl_profile)

)
