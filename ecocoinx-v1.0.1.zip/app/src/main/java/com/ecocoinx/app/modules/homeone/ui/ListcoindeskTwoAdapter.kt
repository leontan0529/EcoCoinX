package com.ecocoinx.app.modules.homeone.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.ecocoinx.app.R
import com.ecocoinx.app.databinding.RowListcoindeskTwoBinding
import com.ecocoinx.app.modules.homeone.`data`.model.ListcoindeskTwoRowModel
import kotlin.Int
import kotlin.collections.List

class ListcoindeskTwoAdapter(
  var list: List<ListcoindeskTwoRowModel>
) : RecyclerView.Adapter<ListcoindeskTwoAdapter.RowListcoindeskTwoVH>() {
  private var clickListener: OnItemClickListener? = null

  override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RowListcoindeskTwoVH {
    val view=LayoutInflater.from(parent.context).inflate(R.layout.row_listcoindesk_two,parent,false)
    return RowListcoindeskTwoVH(view)
  }

  override fun onBindViewHolder(holder: RowListcoindeskTwoVH, position: Int) {
    val listcoindeskTwoRowModel = ListcoindeskTwoRowModel()
    // TODO uncomment following line after integration with data source
    // val listcoindeskTwoRowModel = list[position]
    holder.binding.listcoindeskTwoRowModel = listcoindeskTwoRowModel
  }

  override fun getItemCount(): Int = 3
  // TODO uncomment following line after integration with data source
  // return list.size

  public fun updateData(newData: List<ListcoindeskTwoRowModel>) {
    list = newData
    notifyDataSetChanged()
  }

  fun setOnItemClickListener(clickListener: OnItemClickListener) {
    this.clickListener = clickListener
  }

  interface OnItemClickListener {
    fun onItemClick(
      view: View,
      position: Int,
      item: ListcoindeskTwoRowModel
    ) {
    }
  }

  inner class RowListcoindeskTwoVH(
    view: View
  ) : RecyclerView.ViewHolder(view) {
    val binding: RowListcoindeskTwoBinding = RowListcoindeskTwoBinding.bind(itemView)
  }
}
