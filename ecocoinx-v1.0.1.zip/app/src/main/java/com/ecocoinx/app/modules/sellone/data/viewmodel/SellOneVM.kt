package com.ecocoinx.app.modules.sellone.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.ecocoinx.app.modules.sellone.`data`.model.SellOneModel
import com.ecocoinx.app.modules.sellone.`data`.model.SellOneRowModel
import kotlin.collections.MutableList
import org.koin.core.KoinComponent

class SellOneVM : ViewModel(), KoinComponent {
  val sellOneModel: MutableLiveData<SellOneModel> = MutableLiveData(SellOneModel())

  var navArguments: Bundle? = null

  val selloneList: MutableLiveData<MutableList<SellOneRowModel>> = MutableLiveData(mutableListOf())
}
