package com.ecocoinx.app.modules.ecoeddiefive.ui

import androidx.activity.viewModels
import com.ecocoinx.app.R
import com.ecocoinx.app.appcomponents.base.BaseActivity
import com.ecocoinx.app.databinding.ActivityEcoeddieFiveBinding
import com.ecocoinx.app.modules.ecoeddiefive.`data`.viewmodel.EcoeddieFiveVM
import kotlin.String
import kotlin.Unit

class EcoeddieFiveActivity :
    BaseActivity<ActivityEcoeddieFiveBinding>(R.layout.activity_ecoeddie_five) {
  private val viewModel: EcoeddieFiveVM by viewModels<EcoeddieFiveVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.ecoeddieFiveVM = viewModel
  }

  override fun setUpClicks(): Unit {
  }

  companion object {
    const val TAG: String = "ECOEDDIE_FIVE_ACTIVITY"

  }
}
