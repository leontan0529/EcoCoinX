package com.ecocoinx.app.modules.homeone.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.ecocoinx.app.modules.homeone.`data`.model.HomeOneModel
import com.ecocoinx.app.modules.homeone.`data`.model.ListcoindeskTwoRowModel
import com.ecocoinx.app.modules.homeone.`data`.model.ListdecryptRowModel
import kotlin.collections.MutableList
import org.koin.core.KoinComponent

class HomeOneVM : ViewModel(), KoinComponent {
  val homeOneModel: MutableLiveData<HomeOneModel> = MutableLiveData(HomeOneModel())

  var navArguments: Bundle? = null

  val listdecryptList: MutableLiveData<MutableList<ListdecryptRowModel>> =
      MutableLiveData(mutableListOf())

  val listcoindeskTwoList: MutableLiveData<MutableList<ListcoindeskTwoRowModel>> =
      MutableLiveData(mutableListOf())
}
