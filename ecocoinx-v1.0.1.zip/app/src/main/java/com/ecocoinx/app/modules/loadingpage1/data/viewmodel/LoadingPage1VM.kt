package com.ecocoinx.app.modules.loadingpage1.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.ecocoinx.app.modules.loadingpage1.`data`.model.LoadingPage1Model
import org.koin.core.KoinComponent

class LoadingPage1VM : ViewModel(), KoinComponent {
  val loadingPage1Model: MutableLiveData<LoadingPage1Model> = MutableLiveData(LoadingPage1Model())

  var navArguments: Bundle? = null
}
